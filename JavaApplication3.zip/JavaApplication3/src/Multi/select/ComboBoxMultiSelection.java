
package Multi.select;

import javax.swing.JComboBox;

/**
 *
 * @author Vince Marcos
 * @param <E>
 */
public class ComboBoxMultiSelection<E> extends JComboBox<E> {
    public ComboBoxMultiSelection() {
    }
}
